#!/bin/sh
# Reminder of how to run Include What You Use

make iwyu
