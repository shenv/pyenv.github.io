// Prototype for version receiver.
const char *get_fish_version();
